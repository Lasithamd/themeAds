module FontAwesome
  module Sass
    VERSION = "6.5.2".freeze
  end
end
