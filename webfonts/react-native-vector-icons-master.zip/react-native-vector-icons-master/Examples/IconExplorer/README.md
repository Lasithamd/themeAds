# IconExplorer

To run on OSX you must first install `react-native-desktop` with:

```
$ npm install react-native-desktop@0.6.5
```

To run on Windows you must first install `react-native-windows` with:

```
$ npm install react-native-windows
```
